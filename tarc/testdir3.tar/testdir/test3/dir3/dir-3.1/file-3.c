this is text file file-3.c in directory dir3
