this is text file file-2.c in directory dir2
