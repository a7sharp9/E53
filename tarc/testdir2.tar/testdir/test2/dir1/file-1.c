this is text file file-1.c in directory dir1
